#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]){
    char *argv_word;
    argv_word = argv[1];
    printf("Hello World %s\n", argv_word);
    return 0;
}