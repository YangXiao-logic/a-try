#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    char text[50];
    scanf("%s",text);
    // fgets(text,50,stdin);
    printf("%s2019110038\n", text);
    return 0;
}